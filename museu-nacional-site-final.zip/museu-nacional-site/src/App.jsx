import React, { useEffect, useRef, useState } from 'react';
import { motion, useInView, useScroll, useTransform } from 'framer-motion';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import './App.css';

// Importando as imagens originais
import museuAntes1 from './assets/7BjHWSTRD2EC.jpg';
import museuAntes2 from './assets/HVwP2KuLCHx9.jpg';
import museuAntes3 from './assets/J3YjgMM780ie.jpg';
import museuFogo1 from './assets/xVCoe5JkgwLr.jpg';
import museuFogo2 from './assets/McTc4umKg0uN.jpg';
import museuFogo3 from './assets/ksdsK67UnmD6.jpg';
import museuReconstrucao from './assets/p4KQtv3s5ERf.jpg';

// Importando as novas imagens melhoradas
import interiorMuseu from './assets/interior_museu.jpg';
import dinossauroSala from './assets/dinossauro_sala.png';
import projetoReconstrucao from './assets/projeto_reconstrucao.png';

// Dados atualizados para o gráfico
const dadosPerda = [
  { categoria: 'Acervo Total', antes: 20000000, perdido: 18500000, salvo: 1500000 },
  { categoria: 'Paleontologia', antes: 56000, perdido: 53000, salvo: 3000 },
  { categoria: 'Mineralogia', antes: 60000, perdido: 55000, salvo: 5000 },
  { categoria: 'Arqueologia', antes: 100000, perdido: 85000, salvo: 15000 },
  { categoria: 'Etnologia', antes: 40000, perdido: 35000, salvo: 5000 },
  { categoria: 'Biblioteca', antes: 470000, perdido: 450000, salvo: 20000 }
];

// Componente para seção com scroll reveal
const ScrollRevealSection = ({ children, className = "", delay = 0 }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 75 }}
      animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 75 }}
      transition={{ duration: 0.8, delay }}
      className={className}
    >
      {children}
    </motion.div>
  );
};

// Componente para parallax
const ParallaxImage = ({ src, alt, className = "" }) => {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });
  
  const y = useTransform(scrollYProgress, [0, 1], ["-20%", "20%"]);

  return (
    <div ref={ref} className={`overflow-hidden ${className}`}>
      <motion.img
        src={src}
        alt={alt}
        style={{ y }}
        className="w-full h-full object-cover scale-110"
      />
    </div>
  );
};

function App() {
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-50">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center bg-fixed"
          style={{
            backgroundImage: `linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.4)), url(${museuAntes1})`,
            transform: `translateY(${scrollY * 0.5}px)`
          }}
        />
        <div className="relative z-10 text-center text-white px-4">
          <motion.h1 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="text-6xl md:text-8xl font-bold mb-6 font-serif"
          >
            Museu Nacional do Brasil
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 1 }}
            className="text-xl md:text-2xl mb-8 max-w-4xl mx-auto leading-relaxed"
          >
            Duzentos anos de ciência, uma tragédia que comoveu o mundo, uma reconstrução que simboliza a resistência do conhecimento
          </motion.p>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1.5 }}
            className="animate-bounce"
          >
            <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
              <div className="w-1 h-3 bg-white rounded-full mt-2 animate-pulse"></div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* História do Museu */}
      <section className="py-20 px-4 max-w-7xl mx-auto">
        <ScrollRevealSection className="grid md:grid-cols-2 gap-16 items-center mb-24">
          <div>
            <h2 className="text-5xl font-bold text-amber-900 mb-8 font-serif leading-tight">
              Duzentos Anos de História: O Berço da Ciência Brasileira
            </h2>
            <p className="text-lg text-gray-700 leading-relaxed mb-6">
              Fundado em 6 de junho de 1818 por Dom João VI, o Museu Nacional do Brasil emergiu como a primeira 
              instituição científica do país, estabelecendo as bases para o desenvolvimento da pesquisa e do 
              conhecimento no território brasileiro. Inicialmente denominado Museu Real, a instituição nasceu 
              com o propósito ambicioso de "propagar os conhecimentos e estudos das ciências naturais no Reino do Brasil".
            </p>
            <p className="text-lg text-gray-700 leading-relaxed mb-6">
              Localizado no majestoso Palácio de São Cristóvão, na Quinta da Boa Vista, no Rio de Janeiro, 
              o museu ocupava um edifício de importância histórica singular. Ao longo de seus dois séculos de 
              existência, consolidou-se como uma das mais importantes instituições de pesquisa da América Latina.
            </p>
            <p className="text-lg text-gray-700 leading-relaxed">
              Seu acervo, que chegou a abrigar mais de 20 milhões de itens, representava uma das maiores 
              coleções de história natural e antropológica do hemisfério sul, incluindo fósseis únicos de 
              dinossauros brasileiros, meteoritos raros, múmias egípcias e artefatos indígenas de valor inestimável.
            </p>
          </div>
          <ParallaxImage 
            src={museuAntes2} 
            alt="Vista aérea do Museu Nacional antes do incêndio"
            className="h-[500px] rounded-lg shadow-2xl"
          />
        </ScrollRevealSection>

        <ScrollRevealSection delay={0.2} className="grid md:grid-cols-2 gap-16 items-center mb-24">
          <ParallaxImage 
            src={interiorMuseu} 
            alt="Interior do Museu Nacional com exposições"
            className="h-[500px] rounded-lg shadow-2xl md:order-1"
          />
          <div className="md:order-2">
            <h3 className="text-4xl font-bold text-amber-900 mb-8 font-serif leading-tight">
              Um Palácio de Conhecimento: Onde a Realeza Cedeu Lugar à Ciência
            </h3>
            <p className="text-lg text-gray-700 leading-relaxed mb-6">
              O Palácio de São Cristóvão, que abrigou o Museu Nacional por mais de um século, carregava em sua 
              arquitetura neoclássica a grandeza de uma época e a solenidade necessária para preservar os tesouros 
              da humanidade. Quando Dom Pedro II transferiu a corte, o Paço encontrou sua vocação definitiva como 
              sede do Museu Nacional, em 1892.
            </p>
            <p className="text-lg text-gray-700 leading-relaxed mb-6">
              Cada sala do palácio contava uma história diferente. Os salões que outrora receberam imperadores 
              e diplomatas passaram a exibir esqueletos de dinossauros e fósseis milenares. As antigas câmaras 
              privadas da realeza tornaram-se laboratórios onde pesquisadores desvendavam os mistérios da natureza brasileira.
            </p>
            <p className="text-lg text-gray-700 leading-relaxed">
              A arquitetura do edifício, com seus tetos altos, janelas amplas e corredores majestosos, proporcionava 
              o ambiente ideal para a preservação e exibição do acervo, transformando o antigo palácio em um dos 
              museus mais respeitados da América Latina.
            </p>
          </div>
        </ScrollRevealSection>

        <ScrollRevealSection delay={0.3} className="grid md:grid-cols-2 gap-16 items-center mb-24">
          <div>
            <h3 className="text-4xl font-bold text-amber-900 mb-8 font-serif leading-tight">
              Tesouros da Ciência: Um Acervo Sem Paralelos
            </h3>
            <p className="text-lg text-gray-700 leading-relaxed mb-6">
              Entre as preciosidades do museu, destacava-se o esqueleto completo de dinossauros brasileiros, 
              incluindo espécies descobertas em território nacional. A coleção paleontológica era considerada 
              uma das mais importantes da América do Sul, com fósseis que contavam a história da vida na Terra 
              ao longo de milhões de anos.
            </p>
            <p className="text-lg text-gray-700 leading-relaxed mb-6">
              O crânio de Luzia, com cerca de 11.500 anos, representava o fóssil humano mais antigo encontrado 
              no Brasil e um dos mais importantes das Américas. Suas características únicas forneciam pistas 
              fundamentais sobre a ocupação humana do continente americano.
            </p>
            <p className="text-lg text-gray-700 leading-relaxed">
              A instituição não era apenas um repositório de objetos, mas um centro vivo de produção de conhecimento. 
              Seus pesquisadores contribuíram decisivamente para o avanço das ciências naturais no Brasil, realizando 
              expedições que mapearam a biodiversidade nacional.
            </p>
          </div>
          <ParallaxImage 
            src={dinossauroSala} 
            alt="Sala de dinossauros do Museu Nacional"
            className="h-[500px] rounded-lg shadow-2xl"
          />
        </ScrollRevealSection>
      </section>

      {/* A Tragédia */}
      <section className="py-24 bg-gradient-to-r from-red-900 to-orange-900 text-white">
        <div className="max-w-7xl mx-auto px-4">
          <ScrollRevealSection className="text-center mb-20">
            <h2 className="text-6xl font-bold mb-8 font-serif">2 de Setembro de 2018</h2>
            <p className="text-2xl max-w-5xl mx-auto leading-relaxed">
              Quando o Brasil Perdeu 200 Anos de Memória: A noite que mudou para sempre a história da ciência brasileira. 
              Um incêndio devastador consumiu dois séculos de conhecimento acumulado, deixando uma ferida profunda 
              na memória científica e cultural do país.
            </p>
          </ScrollRevealSection>

          <div className="grid md:grid-cols-3 gap-12 mb-20">
            <ScrollRevealSection delay={0.1} className="text-center">
              <ParallaxImage 
                src={museuFogo1} 
                alt="Início do incêndio no Museu Nacional"
                className="h-80 rounded-lg shadow-2xl mb-6"
              />
              <h3 className="text-2xl font-bold mb-4">19:30h - O Início da Tragédia</h3>
              <p className="text-lg leading-relaxed">
                A investigação da Polícia Federal revelou que o incêndio teve origem em um curto-circuito 
                no sistema de ar-condicionado do auditório. As "gambiarras" no sistema elétrico criaram 
                as condições perfeitas para a tragédia.
              </p>
            </ScrollRevealSection>

            <ScrollRevealSection delay={0.2} className="text-center">
              <ParallaxImage 
                src={museuFogo2} 
                alt="Museu Nacional em chamas durante a madrugada"
                className="h-80 rounded-lg shadow-2xl mb-6"
              />
              <h3 className="text-2xl font-bold mb-4">Madrugada - O Fogo Consome Tudo</h3>
              <p className="text-lg leading-relaxed">
                Durante a madrugada, as chamas consumiram implacavelmente salas inteiras de coleções 
                irresubstituíveis. O crânio de Luzia, meteoritos únicos e milhões de espécimes 
                desapareceram entre as cinzas.
              </p>
            </ScrollRevealSection>

            <ScrollRevealSection delay={0.3} className="text-center">
              <ParallaxImage 
                src={museuFogo3} 
                alt="Destroços do Museu Nacional na manhã seguinte"
                className="h-80 rounded-lg shadow-2xl mb-6"
              />
              <h3 className="text-2xl font-bold mb-4">Manhã Seguinte - O Que Restou</h3>
              <p className="text-lg leading-relaxed">
                Quando o sol nasceu, restavam apenas as paredes de pedra do palácio e uma pequena 
                fração do acervo. A perda foi estimada em 92,5% do acervo total, representando 
                um prejuízo incalculável para a ciência mundial.
              </p>
            </ScrollRevealSection>
          </div>
        </div>
      </section>

      {/* Gráfico de Perdas */}
      <section className="py-24 px-4 max-w-7xl mx-auto">
        <ScrollRevealSection className="text-center mb-20">
          <h2 className="text-5xl font-bold text-gray-900 mb-8 font-serif">
            O Que Perdemos: Um Inventário da Tragédia
          </h2>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            O incêndio destruiu aproximadamente 92,5% do acervo total, representando uma perda incalculável 
            para a ciência e cultura brasileira. Cada categoria de coleção sofreu perdas devastadoras, 
            com milhões de anos de história natural reduzidos a cinzas em uma única noite.
          </p>
        </ScrollRevealSection>

        <ScrollRevealSection delay={0.2} className="bg-white p-12 rounded-2xl shadow-2xl">
          <ResponsiveContainer width="100%" height={500}>
            <BarChart data={dadosPerda} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="categoria" 
                angle={-45}
                textAnchor="end"
                height={100}
                fontSize={12}
              />
              <YAxis />
              <Tooltip 
                formatter={(value, name) => [
                  value.toLocaleString(), 
                  name === 'perdido' ? 'Perdido' : name === 'salvo' ? 'Salvo' : 'Total'
                ]}
                labelFormatter={(label) => `Categoria: ${label}`}
              />
              <Bar dataKey="perdido" fill="#dc2626" name="perdido" />
              <Bar dataKey="salvo" fill="#16a34a" name="salvo" />
            </BarChart>
          </ResponsiveContainer>
          <div className="mt-8 text-center">
            <div className="flex justify-center gap-8">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-red-600 rounded"></div>
                <span className="text-gray-700">Perdido no incêndio</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 bg-green-600 rounded"></div>
                <span className="text-gray-700">Salvo do incêndio</span>
              </div>
            </div>
          </div>
        </ScrollRevealSection>
      </section>

      {/* Reconstrução */}
      <section className="py-24 bg-gradient-to-r from-green-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4">
          <ScrollRevealSection className="grid md:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-5xl font-bold text-green-900 mb-8 font-serif leading-tight">
                Renascendo das Cinzas: A Reconstrução Como Símbolo de Resistência
              </h2>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                A tragédia do incêndio, embora devastadora, revelou também a força da solidariedade e da 
                determinação da comunidade científica brasileira e internacional. Nas semanas que se seguiram 
                ao desastre, doações começaram a chegar de todas as partes do mundo, em uma demonstração 
                comovente de apoio à reconstrução.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-6">
                O projeto de reconstrução, aprovado pelo IPHAN e desenvolvido em parceria com a UNESCO, 
                representa muito mais que a simples restauração de um edifício. Trata-se de um empreendimento 
                que simboliza a capacidade de renascimento da ciência brasileira e a determinação de não 
                permitir que a memória nacional seja apagada pelas chamas do descaso.
              </p>
              <p className="text-lg text-gray-700 leading-relaxed mb-8">
                A nova concepção arquitetônica prevê sistemas modernos de prevenção contra incêndios, 
                climatização adequada e tecnologias digitais avançadas para catalogação e preservação das coleções. 
                O novo Museu Nacional será mais seguro, moderno e preparado para cumprir sua missão educativa.
              </p>
              <div className="bg-green-100 p-8 rounded-xl border-l-4 border-green-600">
                <h3 className="text-2xl font-bold text-green-900 mb-4">
                  Previsão de Reabertura: 2026
                </h3>
                <p className="text-green-800 text-lg">
                  Com novas tecnologias de preservação, sistemas avançados de segurança contra incêndios 
                  e espaços educativos modernos que tornarão o conhecimento mais acessível às futuras gerações.
                </p>
              </div>
            </div>
            <ParallaxImage 
              src={projetoReconstrucao} 
              alt="Projeto arquitetônico de reconstrução do Museu Nacional"
              className="h-[600px] rounded-lg shadow-2xl"
            />
          </ScrollRevealSection>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-amber-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <h3 className="text-3xl font-bold mb-6 font-serif">
            Nunca Esquecer, Sempre Lembrar
          </h3>
          <p className="text-amber-100 max-w-4xl mx-auto text-lg leading-relaxed mb-8">
            O Museu Nacional do Brasil representa mais que um edifício ou uma coleção. Representa nossa 
            memória coletiva, nossa curiosidade científica e nossa determinação de preservar o conhecimento 
            para as futuras gerações. Das cinzas da tragédia, renasce a esperança de um futuro onde a 
            ciência e a cultura sejam valorizadas e protegidas como patrimônios inestimáveis da humanidade.
          </p>
          <div className="text-amber-200 text-sm">
            <p>Em memória dos 200 anos de história perdidos • Em honra aos que lutam pela reconstrução</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
